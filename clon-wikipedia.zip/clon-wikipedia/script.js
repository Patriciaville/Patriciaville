// script.js con definiciones reales y extensas para 5 palabras
const contenido = document.getElementById("contenido");
const formBuscador = document.getElementById("buscador");
const inputBusqueda = document.getElementById("inputBusqueda");
const resultadoBusqueda = document.getElementById("resultadoBusqueda");
const contenedorSignificado = document.getElementById("significado");
const textoSignificado = document.getElementById("textoSignificado");

const diccionario = {
  "árbol": `
    <h3>Árbol</h3>
    <p>
      Un árbol es una planta perenne, generalmente de gran tamaño, que se caracteriza por tener un tronco leñoso y elevado que sostiene una copa formada por ramas y hojas. Los árboles son esenciales para los ecosistemas terrestres ya que producen oxígeno a través de la fotosíntesis, capturan dióxido de carbono, regulan el clima y proporcionan hábitat para una gran variedad de especies animales y vegetales.
    </p>
    <p>
      Los árboles han sido fundamentales para la humanidad, ofreciendo recursos como madera, frutos, sombra y materiales para la construcción y la medicina. Su estructura incluye raíces que absorben agua y nutrientes, un tronco que transporta sustancias y ramas que sostienen las hojas donde ocurre la fotosíntesis.
    </p>
    <p>
      Existen miles de especies de árboles en el mundo, adaptadas a distintos climas y suelos, desde bosques tropicales hasta zonas templadas y boreales. Algunos ejemplos famosos incluyen el roble, el pino, el baobab y el arce.
    </p>
  `,
  "silla": `
    <h3>Silla</h3>
    <p>
      La silla es un mueble diseñado principalmente para que una persona pueda sentarse cómodamente. Generalmente consta de un asiento, un respaldo y cuatro patas, aunque existen múltiples variaciones según su uso, diseño y materiales. Las sillas pueden ser fabricadas con madera, metal, plástico o combinaciones de estos.
    </p>
    <p>
      Este mueble tiene un papel fundamental en la vida cotidiana y en diversos ámbitos como el hogar, la oficina, las escuelas y espacios públicos. Su diseño ha evolucionado con el tiempo, desde las sencillas sillas tradicionales hasta modernas sillas ergonómicas que favorecen la postura y la salud.
    </p>
    <p>
      Además de su función práctica, la silla puede ser un objeto estético y cultural, reflejando estilos artísticos y épocas históricas, como las sillas barrocas, modernas o minimalistas.
    </p>
  `,
  "computadora": `
    <h3>Computadora</h3>
    <p>
      Una computadora es un dispositivo electrónico capaz de procesar información siguiendo un conjunto de instrucciones o programas. Está compuesta por hardware —como el procesador, memoria, almacenamiento y periféricos— y software, que son los programas que permiten realizar tareas específicas.
    </p>
    <p>
      Las computadoras han transformado profundamente la sociedad moderna, facilitando desde la comunicación y el acceso a la información hasta el control de sistemas complejos en industrias, medicina, educación y entretenimiento. Pueden ser de escritorio, portátiles, servidores o incluso dispositivos embebidos en máquinas y electrodomésticos.
    </p>
    <p>
      El desarrollo de la computación comenzó a mediados del siglo XX y ha evolucionado rápidamente, dando lugar a tecnologías como la inteligencia artificial, computación en la nube y big data.
    </p>
  `,
  "internet": `
    <h3>Internet</h3>
    <p>
      Internet es una red mundial de computadoras interconectadas que permite la transmisión y acceso a datos y servicios digitales. Fue desarrollada originalmente en la década de 1960 como un proyecto militar y ha crecido hasta convertirse en una infraestructura fundamental para la comunicación global.
    </p>
    <p>
      A través de internet se accede a servicios como la web, correo electrónico, redes sociales, transmisión de video y mucho más. Ha revolucionado la forma en que las personas se comunican, trabajan, aprenden y se entretienen.
    </p>
    <p>
      Internet funciona mediante protocolos estandarizados que garantizan la interoperabilidad entre distintos dispositivos y redes, siendo el protocolo TCP/IP el más importante. También plantea desafíos en temas de privacidad, seguridad y gobernanza.
    </p>
  `,
  "educación": `
    <h3>Educación</h3>
    <p>
      La educación es un proceso social y cultural mediante el cual las personas adquieren conocimientos, habilidades, valores y actitudes necesarias para su desarrollo personal y la integración en la sociedad. Se realiza formalmente en instituciones como escuelas y universidades, y también de manera informal a través de la experiencia y la interacción social.
    </p>
    <p>
      La educación tiene como objetivo promover el aprendizaje, fomentar el pensamiento crítico, preparar para la vida laboral y contribuir al desarrollo social y económico. En la actualidad, la educación también incluye el uso de tecnologías digitales y metodologías innovadoras para facilitar el aprendizaje.
    </p>
    <p>
      Los sistemas educativos varían en todo el mundo, pero comparten la importancia de garantizar el acceso equitativo y la calidad educativa para todos los individuos.
    </p>
  `
};

function cargarContenido(seccion) {
  contenedorSignificado.style.display = 'none';
  inputBusqueda.value = '';
  resultadoBusqueda.textContent = '';

  if (seccion === "inicio") {
    contenido.innerHTML = `
      <h2>Bienvenido a Wikipedia</h2>
      <p>Wikipedia es una enciclopedia libre, creada y editada por personas de todo el mundo. Contiene millones de artículos en distintos idiomas, abarcando desde temas científicos y académicos hasta historia, arte y cultura popular. Esta versión es un clon educativo inspirado en su diseño.</p>
      <p>Wikipedia se basa en el principio de colaboración abierta, donde cualquier persona con acceso a internet puede editar artículos, contribuyendo así al conocimiento libre.</p>
    `;
  } else if (seccion === "acerca") {
    contenido.innerHTML = `
      <h2>Acerca de Wikipedia</h2>
      <p>Wikipedia fue fundada en 2001 por Jimmy Wales y Larry Sanger. Desde entonces, ha crecido hasta convertirse en uno de los sitios web más visitados del mundo. El proyecto se mantiene sin fines de lucro y es operado por la Fundación Wikimedia.</p>
      <p>La plataforma promueve el conocimiento libre y el acceso abierto a la información. Los contenidos pueden ser utilizados y compartidos bajo licencias libres, lo que permite su uso en la educación, investigación, y medios de comunicación.</p>
    `;
  } else if (seccion === "idiomas") {
    contenido.innerHTML = `
      <h2>Idiomas Disponibles</h2>
      <p>Wikipedia está disponible en más de 300 idiomas, lo que permite a millones de personas acceder a información en su lengua materna. Algunas de las ediciones con mayor número de artículos incluyen:</p>
      <ul>
        <li>Inglés</li>
        <li>Español</li>
        <li>Alemán</li>
        <li>Francés</li>
        <li>Ruso</li>
        <li>Chino</li>
        <li>Japonés</li>
        <li>Portugués</li>
      </ul>
      <p>Además, se promueve el desarrollo de versiones en lenguas indígenas y minoritarias para preservar la diversidad lingüística.</p>
    `;
  } else if (seccion === "contacto") {
    contenido.innerHTML = `
      <h2>Contacto</h2>
      <p>Este sitio es un clon académico sin fines de lucro, diseñado como proyecto estudiantil. No representa a Wikipedia ni a la Fundación Wikimedia.</p>
      <p>Si tienes preguntas sobre el desarrollo de este proyecto, puedes contactar con el responsable académico o el profesor del curso correspondiente.</p>
    `;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  cargarContenido("inicio");

  document.querySelectorAll("nav a").forEach(enlace => {
    enlace.addEventListener("click", (evento) => {
      evento.preventDefault();
      const seccion = evento.target.getAttribute("data-seccion");
      cargarContenido(seccion);
    });
  });
});

formBuscador.addEventListener('submit', (e) => {
  e.preventDefault();
  const texto = inputBusqueda.value.trim().toLowerCase();

  contenido.innerHTML = '';
  resultadoBusqueda.textContent = '';
  contenedorSignificado.style.display = 'none';
  textoSignificado.innerHTML = '';

  if (texto === '') {
    resultadoBusqueda.textContent = 'Por favor, escribe una palabra para buscar.';
    return;
  }

  if (diccionario[texto]) {
    textoSignificado.innerHTML = diccionario[texto];
    contenedorSignificado.style.display = 'block';
  } else {
    resultadoBusqueda.textContent = `No se encontró el significado para: "${texto}"`;
  }
});
